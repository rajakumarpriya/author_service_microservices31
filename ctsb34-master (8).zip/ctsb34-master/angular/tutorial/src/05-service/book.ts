export interface Book{
    title:string,
    author:string,
    price:number
}