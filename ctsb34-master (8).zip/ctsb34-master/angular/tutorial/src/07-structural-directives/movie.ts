export interface Movie{
    title:string,
    director:string,
    rating:number
}