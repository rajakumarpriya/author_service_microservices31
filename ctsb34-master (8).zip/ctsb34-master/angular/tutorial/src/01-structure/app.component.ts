import { Component } from "@angular/core";

@Component({
    selector: "app-root",
    // template: `<div><h2>app component</h2></div>`
    templateUrl: "app.component.html",
    styleUrls: ["app.component.scss"]
})
export class AppComponent{}