import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-movie-byid',
  templateUrl: './movie-byid.component.html',
  styleUrls: ['./movie-byid.component.scss']
})
export class MovieByidComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
