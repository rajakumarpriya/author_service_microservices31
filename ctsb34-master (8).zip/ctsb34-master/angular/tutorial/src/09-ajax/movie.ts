export interface Movie{
    id:number,
    title:string,
    author:string,
    rating:number
}