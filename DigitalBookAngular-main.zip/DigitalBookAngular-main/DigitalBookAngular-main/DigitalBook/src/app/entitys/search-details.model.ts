export class SearchDetails {
    public title: string="";
    public category: string="";
    public publisher: string="";
    public authorName: string="";
    public fromDate: number=0;
    public toDate: number=0;

}