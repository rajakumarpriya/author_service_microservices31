export class AuthorDetils {

    public authorProfileId: number;
    public authorName: string;
    public emailId: string;
    public password: string;
    public jwtToken: string;
}