export class ResponseConstants {
    //status code
    public static SUCCESS: number = 200;


    //status messages
    public static SUCCESS_MESSAGE: string = "suuccess"
}