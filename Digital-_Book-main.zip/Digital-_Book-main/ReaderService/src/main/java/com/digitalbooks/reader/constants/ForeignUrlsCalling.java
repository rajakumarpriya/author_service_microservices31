package com.digitalbooks.reader.constants;

public class ForeignUrlsCalling {

}
