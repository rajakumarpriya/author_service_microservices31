package com.author;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.exceptions.base.MockitoException;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;

import com.digitalbooks.author.publish.AuthorService;


/**
 * @author cogjava3248
 *
 */
@SpringBootTest
@ExtendWith(MockitoExtension.class)
class AuthorServiceApplicationTests {

	@Test
	void contextLoads() {
	}

	@InjectMocks
	AuthorService serviceApplication;
	
	@Test
	public void testLittle() {
		
	}
	
	
	
}
